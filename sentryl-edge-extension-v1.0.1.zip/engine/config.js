﻿/**
 * Sentryl — Centralized Extension Configuration
 * Configurable backend base URL with resilient offline fallback
 */
const SENTRYL_CONFIG = {
  // Production / Development Backend API URL
  API_BASE_URL: (typeof window !== 'undefined' && window.APP_CONFIG && window.APP_CONFIG.API_BASE_URL)
    ? window.APP_CONFIG.API_BASE_URL
    : 'https://api.sentryl.ai',
  
  // Official live Microsoft Edge Add-ons Store URL
  EDGE_EXTENSION_STORE_URL: 'https://microsoftedge.microsoft.com/addons/detail/ORDCKC10MVMZ',

  // Official Public HTTPS Privacy Policy URL
  PRIVACY_POLICY_URL: (typeof window !== 'undefined' && window.APP_CONFIG && window.APP_CONFIG.PRIVACY_POLICY_URL)
    ? window.APP_CONFIG.PRIVACY_POLICY_URL
    : 'https://sentryl-eta.vercel.app/privacy',
  
  // Automatic fallback to embedded heuristic engine if backend API is unreachable
  FALLBACK_TO_CLIENT_ENGINE: true,
  
  // API request timeout in milliseconds
  REQUEST_TIMEOUT_MS: 3500,
  
  // Version and metadata
  VERSION: '1.0.1',
  PLATFORM: 'Microsoft Edge (Chromium MV3)'
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = SENTRYL_CONFIG;
} else if (typeof window !== 'undefined') {
  window.SENTRYL_CONFIG = SENTRYL_CONFIG;
}
