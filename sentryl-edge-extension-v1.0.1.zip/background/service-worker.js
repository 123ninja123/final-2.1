﻿/**
 * Sentryl — Background Service Worker (Manifest V3)
 * Handles badge telemetry, tab routing, and forensic page launch
 */

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Sentryl] Background Service Worker initialized.');
  try {
    chrome.action.setBadgeText({ text: 'AI' });
    chrome.action.setBadgeBackgroundColor({ color: '#3fe8d4' });
  } catch (err) {
    console.error('[Sentryl] Badge initialization error:', err);
  }
});

// Listen for messages from content scripts, dashboard, and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openReportPage') {
    chrome.tabs.create({
      url: chrome.runtime.getURL('dashboard/report.html')
    }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (request.action === 'updateBadge' && request.score !== undefined) {
    try {
      const score = Number(request.score) || 0;
      if (score >= 70) {
        chrome.action.setBadgeText({ text: String(score) });
        chrome.action.setBadgeBackgroundColor({ color: '#ff5c6c' });
      } else if (score >= 40) {
        chrome.action.setBadgeText({ text: String(score) });
        chrome.action.setBadgeBackgroundColor({ color: '#f5c563' });
      } else {
        chrome.action.setBadgeText({ text: '✓' });
        chrome.action.setBadgeBackgroundColor({ color: '#3fe8d4' });
      }
      sendResponse({ ok: true });
    } catch (err) {
      console.error('[Sentryl] Error updating badge:', err);
      sendResponse({ ok: false, error: err.message });
    }
    return true;
  }

  if (request.action === 'getHealth') {
    sendResponse({ status: 'ok', time: Date.now() });
    return true;
  }
});
